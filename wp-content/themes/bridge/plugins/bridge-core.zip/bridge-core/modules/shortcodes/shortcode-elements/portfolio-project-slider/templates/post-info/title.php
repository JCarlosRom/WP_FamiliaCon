<h3 itemprop="name" class="qodef-pps-title">
	<a itemprop="url" class="qode-pps-title-link" href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
</h3>